package productmanagement;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.FileNotFoundException;

class Product {
    private int id;
    private String name;
    private double price;
    private int quantity;
    //constructor creates new product
    public Product(int id, String name, double price, int quantity) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }
    //constructor loads from file
    public Product(String[] data) {
        this.id = Integer.parseInt(data[0]);
        this.name = data[1];
        this.price = Double.parseDouble(data[2]);
        this.quantity = Integer.parseInt(data[3]);
    }
    
    //get and set for product details and to change product details to a string to store
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setID(int id){
        this.id = id;
    }
    public void setName(String name){
        this.name = name;
    }
    
    public void setPrice(double price) {
        this.price = price;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    public String toFileString() {
        return id + "," + name + "," + price + "," + quantity;
    }
}

public class ProductManager {
    private ArrayList<Product> products = new ArrayList<>();//creates products arraylist used to store the product details
    private Scanner scanner = new Scanner(System.in);
    private int nextId = 1;//sets the 1st products ID to 1
    //PLEASE CHANGE THE PATH FILE TO YOUR PATH FILE FOR IT TO WORK!! vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
    private static final String FILE_PATH = "C:\\Users\\Administrator\\OneDrive - CTU Career\\Documents\\NetBeansProjects\\ProductManagement\\Products.txt";
    //PLEASE CHANGE THE PATH FILE TO YOUR PATH FILE FOR IT TO WORK!! ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    public static void main(String[] args) {
        ProductManager productManager = new ProductManager();
        productManager.loadProductsFromFile();
        productManager.run();
    }

    private void run() {
        //welcoming menu for the user
        while (true) {
            System.out.println("\nProduct Management System");
            System.out.println("1. Add Product");
            System.out.println("2. Remove Product");
            System.out.println("3. Edit Product");
            System.out.println("4. View Products");
            System.out.println("5. Save to file");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); //consume the newline character
            //switch statement to handle the users input by calling the method associated with the switch case number
            switch (choice) {
                case 1:
                    addProduct();
                    break;
                case 2:
                    removeProduct();
                    break;
                case 3:
                    editProduct();
                    break;
                case 4:
                    viewProducts();
                    break;
                case 5:
                    saveProductsToFile();
                    break;
                case 6:
                    saveProductsToFile();
                    System.out.println("Exiting the program. Goodbye!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    //error handling when the user enters anything but the numbers
            }
        }
    }
    //method to add products to the products array
    private void addProduct() {
        System.out.println("\nAdding a Product");
        System.out.print("Enter product name: ");//no error handling for product name as they can be anything
        String name = scanner.next();

        double price;
        while (true) {//error handling for when the user enters anything but a double for the product price
            try {
                System.out.print("Enter product price: ");
                price = Double.parseDouble(scanner.next());
                break;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number for price.");
            }
        }

        int quantity;
        while (true) {//error handling for when the user enters anything but a integer for product quantity
            try {
                System.out.print("Enter product quantity: ");
                quantity = Integer.parseInt(scanner.next());
                break;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number for quantity.");
            }
        }
        //creates a new product by adding the users product details
        Product product = new Product(nextId++, name, price, quantity);
        products.add(product);
        System.out.println("Product added successfully.");
    }
    //method to remove products from the array
    private void removeProduct() {
        System.out.println("\nRemoving a Product");
        int id;
        while (true){//error handling for when the user enters anything but a integer for the ID number
            try{
                System.out.print("Enter product ID: ");
                id = Integer.parseInt(scanner.next());
                break;
            } catch (NumberFormatException e){
                System.out.println("Invalid input. Please enter a valid number for ID");
            }
        }

        Product productToRemove = findProductById(id);//uses dinProductById method to load it into productToRemove
        if (productToRemove != null) {
            products.remove(productToRemove);//removed the product
            System.out.println("Product with ID " + id + " removed successfully.");
        } else {
            System.out.println("Product with ID " + id + " not found.");//error handling when the user eneters the wrong ID
        }
    }
    //method to edit the selected product details
    private void editProduct() {
        System.out.println("\nEditing a Product");
        int id;
        while (true){//.error handling for when the user enters anything but an integer for the product ID
            try{
                System.out.print("Enter product ID: ");
                id = Integer.parseInt(scanner.next());
                break;
            } catch (NumberFormatException e){
                System.out.println("Invalid input. Please enter a valid number for ID");
            }
        }
        Product productToEdit = findProductById(id);//uses findProductById method to load into productToEdit
        if (productToEdit != null) {
            //displays the current product details so its easier to edit
            System.out.println("Current Product Details:");
            System.out.println("Name: " + productToEdit.getName());
            System.out.println("Price: " + productToEdit.getPrice());
            System.out.println("Quantity: " + productToEdit.getQuantity());

            System.out.print("Enter new product name: ");//no error handling for product name as they can be anything
            String name = scanner.next();
            productToEdit.setName(name);

            double price;
            while (true) {//error handling for when the user enters anything by a number for the product price
                try {
                    System.out.print("Enter new product price: ");
                    price = Double.parseDouble(scanner.next());
                    break;
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a valid number for price.");
                }
            }
            productToEdit.setPrice(price);

            int quantity;
            while (true) {//error handling for when the user enters anything but an integer for the product quantity
                try {
                    System.out.print("Enter new product quantity: ");
                    quantity = Integer.parseInt(scanner.next());
                    break;
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a valid number for quantity.");
                }
            }
            productToEdit.setQuantity(quantity);

            System.out.println("Product with ID " + id + " updated successfully.");//notfies the user that its been updated
        } else {
            System.out.println("Product with ID " + id + " not found.");//error handling when the ID is not found
        }
    }
    //method to view the products details
    private void viewProducts() {
        System.out.println("\nViewing Products");
        if (products.isEmpty()) {//checks if there is any products and lets the user know if there is none
            System.out.println("No products available.");
        } else {
            for (Product product : products) {//for loops through the product array and prints out the product details for the user to read easily
                System.out.println("ID: " + product.getId() + ", Name: " + product.getName() +
                        ", Price: " + product.getPrice() + ", Quantity: " + product.getQuantity());
            }
        }
    }
    //method to find the product by ID and return the product
    private Product findProductById(int id) {
        for (Product product : products) {
            if (product.getId() == id) {
                return product;
            }
        }
        return null;
    }
    //method to load product details from a save file
    private void loadProductsFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {//loads the product details from the save file
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                products.add(new Product(data));
                nextId = Math.max(nextId, Integer.parseInt(data[0]) + 1);  //updates nextId based on loaded data
            }
            System.out.println("Product details loaded from file.");
        } catch (FileNotFoundException e) {//error hanbdling for when theres no saved product details.
            System.out.println("No saved product details found.");
        } catch (IOException e) {
            System.out.println("Error loading from file: " + e.getMessage());
        }
    }
    //method to save the product details to the save file
    private void saveProductsToFile() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(FILE_PATH))) {
            for (Product product : products) {
                writer.println(product.toFileString());//writes to the save file
            }
            System.out.println("Product details saved to file successfully.");
        } catch (IOException e) {//error handling when the product details cant save to the save file
            System.out.println("Error saving to file: " + e.getMessage());
        }
    }
}
