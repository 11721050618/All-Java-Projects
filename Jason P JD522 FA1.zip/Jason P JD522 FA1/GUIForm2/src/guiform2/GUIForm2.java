/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package guiform2;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

/**
 *
 * @author Administrator
 */
public class GUIForm2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        RegistrationForm r = new RegistrationForm();
        r.setVisible(true);
        
    } 
    
    //tried creating the methods to call into the other class but i had troubles with getting the correct value out ex.
    // if i called this method from RegistrationForm, and use an if statement to check wether its false or true it just wont work.
    // unfortunaly work got me up to my neck and i couldnt spend a lot of time on this.
public static boolean meetPasswordRequirements() {
    RegistrationForm r = new RegistrationForm();
    String password = r.getPasswordText();
    int n = password.length();
    if (n > 8) {
        Pattern isUpper = Pattern.compile("[A-Z]");
        Pattern isNumber = Pattern.compile("[0-9]");
        Pattern isSpecial = Pattern.compile("[!@#$%&*()_+=|<>?{}\\[\\]~-]");

        Matcher hasUpper = isUpper.matcher(password);
        Matcher hasNumber = isNumber.matcher(password);
        Matcher hasSpecial = isSpecial.matcher(password);

        boolean U = hasUpper.find();
        boolean N = hasNumber.find();
        boolean S = hasSpecial.find();

    
        if (U && N && S) {
            //JOptionPane.showMessageDialog(null, "Registration Successful");
            return true;
        }
    }
    
    return false;
}
    //tried using a different way to return true but obv didnt work.
    public static boolean meetUsernameRequirements(){
       RegistrationForm r = new RegistrationForm();
       String username = r.getUsernameText(); 
       Pattern isHash = Pattern.compile("[#]");
       Matcher hasHash = isHash.matcher(username);
       boolean isTrue = false;
       boolean H = hasHash.find();
       boolean hasAmount;
       
       if(username.length() <=9){
           hasAmount = true;
           
           if(H && hasAmount == true){
               JOptionPane.showMessageDialog(null,"Regestration Successful");
               isTrue = true;
           }
       }else{
              isTrue = false; 
           }
        return isTrue;
        
    }
}
